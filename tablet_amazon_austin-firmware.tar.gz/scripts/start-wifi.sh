#!/bin/sh
# see:
# https://github.com/ggow/android_device_amazon_mt8127-common/blob/cm-14.1/rootdir/init.mt8127.rc
# required so that the non chroot kernel can find the firmware where it expects it
#ln -s /opt/bionic/system /system
#ln -s /opt/bionic/system/etc/firmware /etc/firmware
mknod /dev/stpwmt c 190 0
mknod /dev/stpgps c 191 0
mknod /dev/stpbt  c 192 0
mknod /dev/wmtWifi c 153 0
# for bt - not sure if its possible to get that working too ...
mknod /dev/ampc0 c 151 0
mount -o bind /dev /opt/bionic/dev
chroot /opt/bionic /system/bin/wmt_loader
chroot /opt/bionic /system/bin/6620_launcher &
# wait a moment
sleep 5
# enable wifi
echo 1 > /dev/wmtWifi
# disable wifi via: echo 0 > /dev/wmtWifi
